# Research development log

## Hardware and environment — 2026-09-21

Verified two RTX 3090 GPUs, each with 24 GiB VRAM, and approximately 629 GiB system RAM. `nvidia-smi topo -m` reports a PCIe host-bridge connection (PHB), not NVLink. Plan independent pilot runs/seeds on the two GPUs initially; each has its own 24 GiB memory budget. Use RAM for data preparation and caching. Profile before introducing CPU parameter offload or multi-GPU training.

The isolated Python environment for this session is `/tmp/ctm-research-venv`. It contains PyTorch 2.6.0 with CUDA 12.4, pytest, and the repository dependencies. This wheel is listed in the [official PyTorch installation instructions](https://docs.pytorch.org/get-started/previous-versions/). The environment is temporary; recreate it after `/tmp` is cleared.

Both devices were visible through NVML, but `libcuda.so` was absent from the container. The host runs driver 550.144.03. The matching `libnvidia-compute-550_550.144.03-0ubuntu1_amd64.deb` was downloaded from the [NVIDIA Ubuntu 22.04 repository](https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/) and extracted, without system installation, under `/tmp/ctm-nvidia-driver`. Actual CUDA matrix multiplication succeeded on both GPUs after setting the library path below. No kernel driver was changed.

From the repository root, in this session:

```sh
export LD_LIBRARY_PATH=/tmp/ctm-nvidia-driver/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
. /tmp/ctm-research-venv/bin/activate
```

To create a fresh environment on a machine with working CUDA driver libraries:

```sh
python3 -m venv /tmp/ctm-research-venv
. /tmp/ctm-research-venv/bin/activate
python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu124
python -m pip install -r requirements.txt pytest
```

`environment.txt` records the versions used for the initial checks. Restoring that snapshot requires the CUDA wheel index above for the `torch==2.6.0+cu124` entry. The separately extracted driver libraries are not pip packages.

## Completed correctness work

- [x] Check actual CUDA execution on both GPUs.
- [x] Test causal prefix invariance under changed future tokens, padding, and batching.
- [x] Verify order invariance without token positions and sensitivity with positions in the ordinary CTM path.
- [x] Repair existing sample-print formatting for Python 3.10 and guard version-specific optional compiler flags. Verify that the training CLI imports and accepts the new positional-encoding option under PyTorch 2.6.
- [x] Expose `--use_positional_encoding` in both training configuration paths. The legacy default remains false; new text experiments should explicitly enable it.
- [x] Correct temporal MLP sharing documentation: `nlm_groups=1` shares an MLP across all neurons; `nlm_groups=d_latent` gives independent MLPs. Test sharing and gradients.
- [x] Connect `sync_sparse_pairs` from configuration through every thought layer.
- [x] Restore the input histories of each tick during checkpoint recomputation. Before the fix, identical forward losses hid different gradients. Check every parameter gradient with and without dropout, including Hyperloop, matrix streams, and loop embeddings.
- [x] Apply learned loop embeddings in the thought update and verify that they receive gradients.
- [x] Reject nonpositive thought budgets and budgets exceeding tick-indexed parameter tables. A shared head without FiLM or loop embeddings continues to support larger T.
- [x] Verify strict state-dict round trips and inference at a larger T with a shared head.
- [x] Verify a tiny training batch can be learned.
- [x] Add a GPU timing probe with warmup, synchronized timing, BF16, peak memory, and JSON metadata.

The initial 16 research tests produced 9 failures before the fixes and all passed afterward. Additional coverage for checkpointing variants and a tiny-data learning check brings the verified set to 23 distinct tests. These are targeted checks on the actual model, not a claim that the entire pre-existing repository test suite passes.

Run the independent groups in two terminals, or launch both and wait for both exit codes:

```sh
CTM_TEST_DEVICE=cuda:0 python -m pytest tests/test_research_correctness.py \
  -k 'checkpointing or tiny_batch' -q
```

```sh
CTM_TEST_DEVICE=cuda:1 python -m pytest tests/test_research_correctness.py \
  -k 'not (checkpointing or tiny_batch)' -q
```

The tests prefer CUDA when available. An explicit unavailable CUDA device fails instead of silently falling back to CPU. CPU remains useful for lightweight checks and CI. Current gradient-equivalence checks use FP32; the timing probes exercise BF16 training, not BF16 gradient equivalence.

## Preliminary GPU timing

```sh
python -m scripts.profile_research --device cuda:0 --thought-steps 2 \
  --output research/results/preflight_gpu0_t2.json
```

```sh
python -m scripts.profile_research --device cuda:1 --thought-steps 4 \
  --output research/results/preflight_gpu1_t4.json
```

These probes use a 6.24M-parameter model, 4 layers, width 256, a 4096-token vocabulary, batch size 4, sequence length 128, shared temporal MLPs, and BF16 autocast. They include backward and AdamW steps. Parameters remain FP32, and the source records the full configuration. They measure a repeated synthetic batch with no data loading or compilation and do not estimate quality, a fully optimized throughput ceiling, or the throughput of the planned larger language models. Some probes ran alongside correctness checks on the other GPU; shared CPU resources can affect timing. Re-profile the selected actual pilot configuration before budgeting long runs.

Initial observed results (20 timed steps after 5 warmup steps):

| Device / budget | Tokens/s | Median step | Peak allocated GPU memory |
|---|---:|---:|---:|
| GPU 0, T=2 | 2,343 | 234 ms | 0.494 GiB |
| GPU 1, T=4 | 1,274 | 399 ms | 0.833 GiB |

These are separate-device timing observations; do not interpret their ratio as a controlled scaling result. The JSON files preserve all per-step timings and losses.

## Compatibility and remaining work

Applying loop embeddings changes outputs for configurations that previously enabled the unused `use_loop_pos_emb` flag. Old checkpoints with that flag contain embeddings that did not learn through this path. Reevaluate them; reproduce historical results using the original code revision. Similarly, an old nondefault `sync_sparse_pairs` configuration may describe a checkpoint that actually used 256 pairs. Recover the effective shape from the checkpoint before migration. Checkpointed training after the gradient fix should be treated as a new experiment version.

## Canonical configuration milestone

- [x] Freeze a position-aware CTM architecture, independent temporal MLPs, sparse synchronization, shared readout, and final-tick loss in [`configs/ctm_reference_v1.json`](configs/ctm_reference_v1.json).
- [x] Make attention residuals optional while retaining legacy defaults; disable them in the reference preset.
- [x] Require complete configurations, record manifest hashes, and provide a launcher with explicit data splits, seed, device, and fresh checkpoint directory.
- [x] Align research training and profiling: BF16 autocast with FP32 parameters and AdamW state.
- [x] Pass 11 canonical checks and 23 existing model checks on GPUs.
- [x] Complete a 101-step synthetic training smoke on GPU 0, strictly reload its checkpoint, verify finite FP32 parameters/optimizer moments, and run a separate evaluation forward pass.
- [x] Profile the final 29,557,841-parameter configuration on GPU 1: approximately 1,627 tokens/s, 303 ms median update, and 1.861 GiB peak allocated memory.

See [canonical model details](CANONICAL_MODEL.md) for exact choices, commands, limitations, and parameter breakdown. Machine-readable records are `results/canonical_profile_gpu1.json` and `results/canonical_training_smoke.json`. The synthetic training checkpoint lives under `/tmp`; it is not a paper result. The updated probe used the second GPU concurrently with the training smoke, so host contention can affect timing.

## Baselines and common experiment interface

- [x] Implement the standard decoder Transformer and an explicitly documented Geiping-style recurrent-depth adaptation.
- [x] Freeze baseline presets, including a separate variable-depth training variant.
- [x] Share configuration loading, model construction, training/data policy, profiling, checkpoint loading, and conditional-likelihood evaluation across all three families.
- [x] Record data/tokenizer/source hashes, training tokens, depth counts, parameter categories, and GPU timing.
- [x] Pass 19 baseline/shared-runner GPU checks plus 38 canonical/evaluation regressions. Both baseline families learn a tiny batch; all three families train and save through the shared runner.
- [x] Profile each full development preset on the 3090s. See [baseline details and results](BASELINES.md).

The shared runner uses a new windowing and learning-rate policy, documented in `BASELINES.md`. Keep those runs distinct from the earlier legacy-trainer CTM smoke. The baselines are implemented; matched budgets and meaningful task results remain to be established.

## Controlled tasks and first pilots

- [x] Generate fixed addition and pointer-chasing datasets with semantic split disjointness, difficulty annotations, and file hashes.
- [x] Add a common 71-token character vocabulary, answer/EOS-only supervision, and token-weighted accumulation and validation.
- [x] Add unconstrained greedy exact-answer evaluation with per-example predictions and difficulty breakdowns.
- [x] Pass 10 task-specific checks and 30 baseline/canonical regression checks on GPUs.
- [x] Complete six single-seed pilots: three models × two tasks, 600 updates and 19,200 examples each, using both 3090s.
- [x] Review learning curves: addition learns in distribution; pointer chasing remains near guessing. Defer seed expansion until the pointer learning gate passes.

See [task protocol and interpretation](ALGORITHMIC_TASKS.md), [results](results/algorithmic_v1/RESULTS.md), and [learning curves](results/algorithmic_v1/learning_curves.png). These are exploratory, unmatched-budget results, not paper evidence of architecture superiority.

## Next tasks, in order

The evaluation-scoring milestone is implemented and validated; see [evaluation validation](EVALUATION.md). Historical benchmark scores still need reevaluation from their original checkpoints.

1. Diagnose pointer learning with one-hop lookup and tiny-set overfitting; address carry/position generalization in addition. Expand seeds only after the learning gates pass.
2. Use the measured costs to select comparable model/budget variants, add FLOP accounting, and begin the main experiment registry.

The first controlled-task development comparison is complete. No confirmatory multi-seed or paper-scale training run has been launched. See `../RESEARCH_PLAN.md` for the overall study design.
