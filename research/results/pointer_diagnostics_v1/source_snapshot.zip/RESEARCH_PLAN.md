# CTM-Transformer comparative research plan

Draft: 2026-09-21. Based on static inspection of repository revision `73f90c4`, the saved evaluation JSON files, and the primary literature linked below. Existing metrics have not been reproduced. Hardware is now verified: two RTX 3090 GPUs (24 GiB each), approximately 629 GiB system RAM, and PCIe connectivity. Total compute budget and submission date remain unconfirmed; sizes and schedules below are planning proposals. See [research development log](research/README.md) for completed correctness fixes, GPU setup, and preliminary timings; the audit below records the original revision.

**Working title:** *Does Temporal Synchronization Improve Recurrent Computation in Language Models?*

**Central question:** At comparable training and inference budgets, do explicit activation histories and synchronization improve prediction, iterative problem solving, or generalization beyond what recurrent depth alone provides?

The contribution should be a precise architecture and a controlled empirical answer. A broad claim that the model “thinks” or that recurrence itself is novel would be difficult to defend. A useful negative result could identify when temporal history fails to help, provided the baselines, controls, and analysis are strong.

## 1. Establish what the current model actually does

The default CTM path maintains a latent vector and pre/post-activation histories for every token position and thought layer. Synchronization of post-activation histories generates queries that causally attend to token embeddings. A gated synapse combines retrieved information with the current latent state; a temporal MLP processes pre-activation history. Layers repeat across thought ticks. The output head reads the final latent vector concatenated with the current token embedding.

Distinguish three axes in the paper: token position, layer index, and thought tick. Temporal history here is across internal computation; buffers reset on each forward call. It is not persistent memory across generated tokens. The current implementation also mixes previous layer outputs through attention residuals.

The matrix-stream option replaces both the temporal MLP and synchronization. It is a separate architecture variant and cannot substantiate a claim about those mechanisms.

Before committing to paper-scale training, resolve these issues:

| Observation from the current code | Required action and scientific implication |
|---|---|
| `NeuronLevelModels` stores one MLP per `nlm_groups`; with the default value 1, all neurons share that MLP. This contradicts comments describing unique per-neuron weights. | Specify shared, grouped, and independent temporal MLPs accurately. In this implementation, `nlm_groups=d_latent` gives independent temporal MLPs. Benchmark the parameter and speed costs before choosing the canonical variant. |
| Token positional embeddings are disabled by default, while attention reads static token embeddings. | Test order sensitivity. For the ordinary path without other order-aware features, the final position should be invariant to permutations of earlier tokens that preserve their multiset and the final token: its attention reads an unordered set of embeddings. This is a static-code inference to verify. Thought time does not supply token order. Establish a position-aware main configuration. |
| Synchronization generates attention queries; the final head reads latent state plus token embedding, not synchronization directly. | Describe this explicitly as an adaptation of CTM. Do not claim an exact reproduction of the original CTM readout. |
| FiLM parameters and per-tick adapters are indexed by thought tick and allocated only up to configured T. | Use a shared readout, or define and validate an extrapolatable conditioning rule before evaluating beyond trained T. Merely allocating extra untrained rows is not valid depth extrapolation. |
| `loop_pos_emb` is allocated but has no forward use found in this revision. | Audit whether intended configuration switches affect execution; remove claims about inactive features or implement and verify them in a new version. |
| `sync_sparse_pairs` is configurable but is not passed through `ThoughtLayer` to `SynchronizationComputer`. | Wire and verify this before interpreting a sweep over the number of synchronization pairs. |
| Attention residuals run unconditionally; optional FEEC, Hyperloop, Engram, sparse attention, and quantization create additional differences. | Make the main architecture reproducible and attribute each retained addition. Use switches or controls to isolate the CTM mechanisms. Preserve the current recipe as a named reference configuration. |
| The harness tokenizes context and continuation separately, omits the first continuation token when context is empty, and permits missing checkpoint keys. | Check scoring against the reference harness adapter for the exact tokenizer, including whitespace boundaries, empty contexts, truncation, padding, and shifts. Require strict checkpoint loading or an explicit validated migration. These are audit findings, not a demonstrated explanation for the saved scores. |
| Generation reruns the prefix, and the model projects vocabulary logits every tick. | Profile the actual implementation. Make caching and final-only readout explicit engineering tasks if claiming practical inference efficiency; verify numerical equivalence after optimization. |

Useful correctness gates include future-token perturbation invariance, identical-prefix logits under padding/batching, tiny-dataset overfitting, checkpoint round trips, and gradient agreement with checkpointing enabled versus disabled. Stateful FIFO buffers make the last check particularly relevant. Add generation and rolling likelihood support only when the selected evaluation requires them.

## 2. Interpret existing evidence conservatively

The stored `eval_t_sweep.json` reports the following raw accuracy percentages:

| Task | T=1 | T=4 | T=8 |
|---|---:|---:|---:|
| ARC-Easy | 27.02 | 29.80 | 29.04 |
| HellaSwag | 26.09 | 25.96 | 26.14 |
| PIQA | 52.88 | 53.10 | 52.72 |
| LAMBADA | 0.0194 | 0.0194 | 0.0194 |

LAMBADA perplexity is approximately 0.883M, 3.175M, and 2.184M respectively. This is a task-specific perplexity and should not be presented as general corpus perplexity. These results give mixed evidence about additional ticks, with weak performance on several tasks. They do not establish superiority over another architecture or a consistent improvement with compute.

The JSON files do not include the checkpoint identity, complete training budget, tokenizer revision, or per-example predictions. Recover those if possible, but treat these runs as exploratory. Do not infer statistical significance from differences between aggregate scores or treat the reported example-level standard errors as training-seed uncertainty.

## 3. Position the work against the literature

The original [Continuous Thought Machines paper](https://arxiv.org/abs/2505.05522) supplies the temporal neuron processing and synchronization ideas. The paper must identify which mechanisms are retained, changed, or omitted.

Use [Geiping et al., *Scaling up Test-Time Compute with Latent Reasoning: A Recurrent Depth Approach*](https://arxiv.org/abs/2502.05171) as the principal recurrent-depth reference. Its prelude, recurrent core, input injection, coda, and variable-depth training matter; repeating an arbitrary block is an incomplete reproduction. Consult the [authors' implementation](https://github.com/seal-rg/recurrent-pretraining) and document every small-scale adaptation. Their released 3.5B model is contextual evidence, not a controlled baseline for a smaller model trained on different data.

[Universal Transformers](https://arxiv.org/abs/1807.03819) establish earlier depth recurrence. More recent work also narrows the novelty claim: [LoopFormer](https://arxiv.org/abs/2602.11451) addresses variable compute through trajectory conditioning and shortcut consistency; [Parcae](https://arxiv.org/abs/2604.12946) studies stability and scaling of looped language models; [SpiralFormer](https://arxiv.org/abs/2602.11698) studies recursion across sequence resolutions. Review these before freezing the design, and repeat the literature search before submission. This initial search is not an exhaustive novelty review.

Choose one recent comparator that most directly overlaps the eventual claim: LoopFormer for budget flexibility, or Parcae for stability. Additional architectures should earn their place by testing a specific alternative explanation.

## 4. Hypotheses and baselines

Freeze primary hypotheses after development pilots and before confirmatory runs:

1. **Prediction at a fixed budget:** CTM improves held-out next-token cross-entropy or task accuracy over recurrent depth at comparable training and inference compute.
2. **Useful additional computation:** a single CTM checkpoint improves with additional ticks, including on harder examples, and improves more per unit of compute than the recurrent baseline.
3. **Mechanism attribution:** temporal processing and synchronization explain the benefit after controlling for state size, readout conditioning, auxiliary losses, and other architecture changes.

Train the following core families from scratch on identical data:

| Family/control | Purpose |
|---|---|
| Standard decoder-only Transformer with untied layers | Establish ordinary language-model quality and compute efficiency. |
| Recurrent-depth Transformer adapted from Geiping et al. | Test whether repeating a well-designed Transformer core explains the result. |
| Canonical CTM-Transformer | Test the complete proposed mechanism. |
| CTM scaffold with temporal MLP and synchronization both replaced | Preserve its cross-attention, input injection, residual structure, and head while removing the claimed mechanisms. This is not automatically equivalent to the published recurrent-depth model. |
| Recurrent/scaffold control with a simple history buffer or larger state | Test whether extra memory capacity explains a gain attributed to synchronization. |

Use parameter-matched and compute-matched Transformer configurations where needed. A T=1 CTM is a useful ablation, but it is not the standard Transformer baseline. Preserve strong conventional design choices in the ordinary baseline; use the scaffold controls for strict mechanism isolation.

## 5. Fair comparison protocol

Use one tokenizer, document-level data splits, fixed corpus revisions, the same sequence lengths and packing policy, and identical evaluation examples. Count unique trainable parameters, including embeddings and heads, once; also report non-embedding parameters and recurrent state memory. Record effective depth as actual block applications, including nested loops.

Run two complementary training comparisons:

- **Equal training FLOPs:** stop each model at common cumulative compute checkpoints. Faster or cheaper architectures may see more tokens. This is the main compute-efficiency comparison.
- **Equal training tokens:** compare common data-prefix milestones and report the compute spent. This measures data efficiency and is not an equal-cost experiment.

A trajectory can supply checkpoints for both analyses where its budget reaches them. Report inference quality versus measured FLOPs and wall time, not simply versus tick count. CTM and recurrent-depth ticks may have very different costs. Include vocabulary projections, temporal MLPs, synchronization, attention residuals, recomputation, and teacher costs when applicable. The shortcut `6 × unique parameters × tokens` is not a sufficient compute estimate for these recurrent models.

Use the same hardware, precision, batch sizes, context lengths, and warmup/timing procedures for speed comparisons. Measure prefill separately from decoding, peak memory, median latency and a tail percentile, and throughput. Record caching policy and include each model's required recurrent/KV state. Until comparable optimized decoding exists, qualify latency as implementation performance.

Give each family an equal documented tuning budget, allowing learning rates and stability settings to differ when validation supports it. Log all attempted configurations. Start with ordinary cross-entropy and no distillation for architecture attribution. If teacher supervision is needed, provide identical teacher signals to every family and report cache generation cost and provenance separately as well as in total resource accounting.

## 6. Experiments in stages

**Stage A: correctness and feasibility.** Complete the audits, implement the two main baselines, and profile small configurations. Select a compact position-aware CTM with explicit temporal MLP sharing semantics and a shared output head. Use ordinary dense attention and a single level of thought recurrence initially; assess additional components only when needed. Confirm all three main families can learn a tiny dataset and an elementary task.

**Stage B: controlled algorithmic pilot.** Use two complementary generated tasks, for example multi-digit arithmetic and pointer chasing or graph reachability. Train on bounded lengths/depths and reserve longer inputs and greater reasoning depths for generalization tests. Hold graph size fixed while varying path depth in a separate test so length and difficulty are not always confounded. Use disjoint instances, fixed generators, exact answer metrics, and identical answer-only supervision. Treat chain-of-thought supervision as a separate experiment if introduced.

Run five seeds at a small scale, initially about 5–20M non-embedding parameters subject to profiling. Evaluate trained thought budgets such as 1, 2, 4, and 8. Test 12 and 16 only after eliminating tick-index limits and clearly distinguish depths seen during training from unseen depths. Diagnose both trained depth-specific models and truncation of a single checkpoint; these answer different questions.

**Stage C: language modeling.** Choose a fixed, documented slice of the available training corpus with document-disjoint validation and test sets, plus one held-out domain for transfer. The primary metric is final-tick token-weighted cross-entropy; report perplexity derived from it. Synthetic answer-only losses and language-model all-token losses must be reported separately.

A provisional main scale is 30–100M non-embedding parameters and 100–500M tokens for the initial language pilot. These are feasibility proposals, not a claim of sufficient training. Use learning curves and measured throughput to set the final budget. Train the three principal families with at least three seeds, using common FLOP and token checkpoints. Keep the existing ARC-Easy, HellaSwag, PIQA, and LAMBADA suite as secondary evaluation after repairing/validating the adapter. Add difficult generation benchmarks only if pilot competence makes them informative.

**Stage D: confirmation and scale transfer.** Run the decisive ablations below, then repeat the three main families at a second feasible size, provisionally 100–300M non-embedding parameters. A second scale strengthens generality; if unavailable, scope the paper to the measured regime. Include the selected recent recurrent comparator when the intended claim requires it. Do not spend most of the budget on one large CTM checkpoint before the controlled pilot succeeds.

## 7. Ablations that establish causality

First run a 2×2 factorial study inside the same CTM scaffold:

| Temporal MLP over history | Synchronization queries | Interpretation |
|---|---|---|
| Off | Off | Scaffold control |
| On | Off | Temporal processing contribution |
| Off | On | Synchronization contribution |
| On | On | Full CTM and interaction between mechanisms |

“Temporal MLP off” replaces that update with a current-state transformation. Keep the post-activation buffer when synchronization requires it. “Synchronization off” derives queries from the current state using a comparable projection. Train each variant from scratch; give removed capacity an appropriately matched control rather than adding unused parameters.

Then prioritize history lengths 1/4/8/16; shared/grouped/independent temporal MLPs; synchronization summary versus sparse pairs; and fixed versus variable-depth training. Test loss/readout changes separately: final-only CE versus multi-tick supervision, with and without the monotonic penalty, and shared readout versus tick-specific FiLM. Apply the same auxiliary recipe to recurrent baselines when feasible. An objective rewarding improvement across ticks cannot itself establish a unique architectural advantage.

For mechanism analysis, measure state changes, prediction changes, and held-out loss at every tick. Freeze a latent state while varying FiLM/readout tick to test how much apparent refinement comes from the head. Combine trained ablations with inference interventions such as erasing old history, perturbing synchronization, or shuffling temporal order. Shuffling history tests the temporal MLP but may leave an unweighted Gram synchronization statistic unchanged; choose interventions based on the actual statistic. Report intervention distribution shift and avoid treating attractive trajectory plots as proof of reasoning.

Adaptive stopping is optional follow-up work. Choose thresholds only on validation data and include their overhead, calibration, average ticks, and tail latency. The main claim should first hold at fixed compute budgets.

## 8. Statistical protocol and decision gates

Save per-example outputs and compare models on the same examples. Report means and spread across training seeds. For evaluation uncertainty, use paired bootstrap intervals over independent examples or documents; avoid treating correlated tokens as independent observations. For synthetic data, distinguish training seed from test-generator seed. Preselect a small primary endpoint set and label other analyses exploratory.

Use development pilots to estimate variance and select a practically meaningful effect threshold before confirmation. For example, decide whether an accuracy improvement at fixed compute or a compute reduction at fixed quality is large enough to matter for the chosen application. There is no universal percentage that guarantees publishability.

Progression gates:

1. **Correctness:** resolve order sensitivity, scoring, configuration, state, and checkpoint issues; all families learn elementary tasks.
2. **Signal:** pilots show a reproducible advantage or an informative, reproducible failure mode. Flat ticks alone are a diagnosis target.
3. **Attribution:** history/synchronization controls distinguish the mechanism from extra compute, memory, readout conditioning, and training losses.
4. **Generalization:** confirm on fresh seeds and locked test data, preferably across two task families and a second scale.
5. **Claim selection:** choose an architecture paper if the mechanism adds value, an efficiency paper if quality-versus-cost improves, or a focused empirical study if the main finding is a well-supported limitation. Admission to any venue remains uncertain.

## 9. Budget, deliverables, and paper structure

Allocate an initial planning budget of roughly 15% to correctness/profiling/pilots, 45% to main comparisons, 25% to decisive ablations, and 15% to confirmation and reruns. Estimate actual GPU hours from measured aggregate training throughput: `GPU hours = accelerator count × tokens / aggregate tokens per second / 3600`, summed per stage when T changes. Add tuning, evaluation, failed runs, and teacher preparation explicitly. Existing run-command throughput comments are not a measured budget for new experiments.

An illustrative sequence is one week for specification/audits, one to two weeks for baselines and pilots, two to four weeks for main runs, and two weeks for confirmation and writing. This is an organizational sequence, not a hardware-backed completion estimate. Prefer fewer well-controlled experiments with seeds over many unsupported feature combinations.

Required figures/tables:

1. Architecture diagram with token, layer, and thought axes; show all recurrent state and readout paths.
2. Held-out quality versus cumulative training FLOPs, with seed variation.
3. Quality versus inference FLOPs and latency, including a frontier of ordinary Transformer configurations.
4. Task difficulty/length versus accuracy at several thought budgets, marking unseen depths.
5. Factorial ablation table with parameters, memory, compute, and uncertainty.
6. Tick-wise dynamics plus an intervention that tests the proposed explanation.

Draft the paper as: problem and hypotheses; related work; exact update equations and complexity; experimental protocol; main comparisons; ablations and mechanism analysis; limitations and conclusion. Write methods during implementation, but write the abstract and final claims after confirmation. Derive cost for each synchronization method rather than assuming every variant materializes a D×D matrix.

Release the canonical configuration, baseline configurations, pinned environment, data manifests and generator seeds, evaluation adapter checks, strict checkpoint loader, compute accounting, raw metrics, per-example predictions where distributable, and plotting scripts. Record code commit, tokenizer, dataset revision, seed, tokens, training FLOPs, thought-depth distribution, checkpoint, and hardware for every result. Store a machine-readable experiment registry and distinguish exploratory runs from confirmatory runs.

**First concrete milestone:** a reproducible small-scale comparison of standard Transformer, recurrent-depth Transformer, and canonical CTM on two controlled tasks, accompanied by a verified evaluation harness and measured cost. Use that evidence to set the language-model scale and finalize the paper's claim.
